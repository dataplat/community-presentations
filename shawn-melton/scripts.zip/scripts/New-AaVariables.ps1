<# List of variables we need #>
$params = @{
    Name        = 'AzureSqlServer'
    Encrypted   = $false
    Value       = 'dbatoolspbi.database.windows.net'
    Description = 'Azure SQL Server hosting inventory database'
}

New-AzAutomationVariable @params
# Set-AzAutomationVariable -Name 'AzureSqlServer' -Value 'dbatoolspbi.database.windows.net' -Encrypted $false

$params = @{
    Name = 'AzureSqlDatabase'
    Encrypted = $false
    Value     = 'dbapbi'
    Description = 'Azure SQL Database hosting inventory data'
}
New-AzAutomationVariable @params

$params = @{
    Name = 'tableSessionLog'
    Encrypted = $false
    Value     = "[sessionlog]"
    Description = 'Table for dbatools errorlog'
}
New-AzAutomationVariable @params

