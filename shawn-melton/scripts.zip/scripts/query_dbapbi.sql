/* Grab unique server list */
SELECT ComputerName, 
    CASE InstanceName 
        WHEN 'MSSQLSERVER' THEN NULL
        ELSE InstanceName
    END AS InstanceName,
    MAX(CaptureDate) AS LastCapture
FROM servers
WHERE CaptureDate > '05/03/2019'
GROUP BY CaptureDate, ComputerName, InstanceName

SELECT * FROM osinfo
SELECT * FROM diskspace
SELECT * FROM systeminfo
SELECT * FROM databaseinfo
SELECT * FROM databasespace

/* Cleanup tables */
DROP TABLE osinfo
DROP TABLE diskspace
DROP TABLE systeminfo
DROP TABLE databaseinfo
DROP TABLE databasespace