USE [raspberrypi];
SET NOCOUNT ON;
GO
PRINT '*******Working on raspberrypi**********'
/* Badges */
DECLARE @messagebody XML
SELECT @messagebody = BulkColumn
FROM OPENROWSET(BULK 'C:\temp\StackExchange\raspberrypi.stackexchange.com\Badges.xml',SINGLE_CLOB) AS x

INSERT INTO [dbo].[Badges] ([UserId],[Name],[Date])
SELECT
    r.a.value('@UserId','int') AS [UserId],
    r.a.value('@Name','varchar(150)') AS [Name],
    r.a.value('@Date','datetime') AS [Date]
FROM @messagebody.nodes('/badges/row') AS r(a)
GO
PRINT '[x] Badges data loaded'

/* Comments */
DECLARE @messagebody XML
SELECT @messagebody = BulkColumn
FROM OPENROWSET(BULK 'C:\temp\StackExchange\raspberrypi.stackexchange.com\Comments.xml',SINGLE_CLOB) AS x

INSERT INTO [dbo].[Comments] ([Id],[PostId],[Score],[Text],[CreationDate],[UserId])
SELECT
    r.a.value('@Id','int') AS [Id],
    r.a.value('@PostId','int') AS [PostId],
    r.a.value('@Score','int') AS [Score],
    r.a.value('@Text','varchar(600)') AS [Text],
    r.a.value('@CreationDate','datetime') AS [CreationDate],
    r.a.value('@UserId','int') AS [UserId]
FROM @messagebody.nodes('/comments/row') AS r(a)
GO
PRINT '[x] Comments data loaded'

/* PostHistory */
DECLARE @messagebody XML
SELECT @messagebody = BulkColumn
FROM OPENROWSET(BULK 'C:\temp\StackExchange\raspberrypi.stackexchange.com\PostHistory.xml',SINGLE_CLOB) AS x

INSERT INTO [dbo].[PostHistory] ([Id],[PostHistoryTypeId],[PostId],[RevisionGUID],[CreationDate],[UserId],[UserDisplayName],[Comment],[Text],[CloseReasonId])
SELECT
    r.a.value('@Id','int') AS [Id],
    r.a.value('@PostHistoryTypeId','int') AS [PostHistoryTypeId],
    r.a.value('@PostId','int') AS [PostId],
    r.a.value('@RevisionGUID','nvarchar(50)') AS [ReviewionGUID],
    r.a.value('@CreationDate','datetime') AS [CreationDate],
    r.a.value('@UserId','int') AS [UserId],
    r.a.value('@UserDisplayName','varchar(150)') AS [UserDisplayName],
    r.a.value('@Comment','nvarchar(max)') AS [Comment],
    r.a.value('@Text','nvarchar(max)') AS [Text],
    r.a.value('@CloseReasonId','int') AS [CloseReasonId]
FROM @messagebody.nodes('/posthistory/row') AS r(a)
GO
PRINT '[x] PostHistory data loaded'

/* PostLinks */
DECLARE @messagebody XML
SELECT @messagebody = BulkColumn
FROM OPENROWSET(BULK 'C:\temp\StackExchange\raspberrypi.stackexchange.com\PostLinks.xml',SINGLE_CLOB) AS x

INSERT INTO [dbo].[PostLinks] ([Id],[CreationDate],[PostId],[RelatedPostId],[PostLinkTypeId])
SELECT
    r.a.value('@Id','int') AS [Id],
    r.a.value('@CreationDate','datetime') AS [CreationDate],
    r.a.value('@PostId','int') AS [PostId],
    r.a.value('@RelatedPostId','int') AS [RelatedPostId],
    r.a.value('@PostLinkTypeId','int') AS [PostLinkTypeId]
FROM @messagebody.nodes('/postlinks/row') AS r(a)
GO
PRINT '[x] PostLinks data loaded'

/* Posts */
DECLARE @messagebody XML
SELECT @messagebody = BulkColumn
FROM OPENROWSET(BULK 'C:\temp\StackExchange\raspberrypi.stackexchange.com\Posts.xml',SINGLE_CLOB) AS x

INSERT INTO [dbo].[Posts] ([Id],[PostTypeId],[ParentId],[AcceptedAnswerId],[CreationDate],[Score],[ViewCount],[Body],[OwnerUserId],[LastEditorUserId],[LastEditorDisplayName],[LastEditDate],[LastActivityDate],[CommunityOwnedDate],[ClosedDate],[Title],[Tags],[AnswerCount],[CommentCount],[FavoriteCount])
SELECT
    r.a.value('@Id','int'),
    r.a.value('@PostTypeId','int'),
    r.a.value('@ParentId','int'),
    r.a.value('@AcceptedAnswerId','int'),
    r.a.value('@CreationDate','datetime'),
    r.a.value('@Score','int'),
    r.a.value('@ViewCount','int'),
    r.a.value('@Body','nvarchar(max)'),
    r.a.value('@OwnerUserId','int'),
    r.a.value('@LastEditorUserId','int'),
    r.a.value('@LastEditorDisplayName','varchar(250)'),
    r.a.value('@LastEditDate','datetime'),
    r.a.value('@LastActivityDate','datetime'),
    r.a.value('@CommunityOwnedDate','datetime'),
    r.a.value('@ClosedDate','datetime'),
    r.a.value('@Title','varchar(150)'),
    r.a.value('@Tags','varchar(150)'),
    r.a.value('@AnswerCount','int'),
    r.a.value('@CommentCount','int'),
    r.a.value('@FavoriteCount','int')
FROM @messagebody.nodes('/posts/row') AS r(a)
GO
PRINT '[x] Posts data loaded'

/* Tags */
DECLARE @messagebody XML
SELECT @messagebody = BulkColumn
FROM OPENROWSET(BULK 'C:\temp\StackExchange\raspberrypi.stackexchange.com\Tags.xml',SINGLE_CLOB) AS x

INSERT INTO [dbo].[Tags] ([Id],[TagName],[Count],[ExcerptPostId],[WikiPostId])
SELECT
    r.a.value('@Id','int'),
    r.a.value('@TagName','varchar(250)'),
    r.a.value('@Count','int'),
    r.a.value('@ExcerptPostId','int'),
    r.a.value('@WikiPostId','int')
FROM @messagebody.nodes('/tags/row') AS r(a)
GO
PRINT '[x] Tags data loaded'

/* Users */
DECLARE @messagebody XML
SELECT @messagebody = BulkColumn
FROM OPENROWSET(BULK 'C:\temp\StackExchange\raspberrypi.stackexchange.com\Users.xml',SINGLE_CLOB) AS x

INSERT INTO [dbo].[Users] ([Id],[Reputation],[CreationDate],[DisplayName],[EmailHash],[LastAccessDate],[WebsiteUrl],[Location],[Age],[AboutMe],[Views],[UpVotes],[DownVotes])
SELECT
    r.a.value('@Id','int'),
    r.a.value('@Reputation','int'),
    r.a.value('@CreationDate','datetime'),
    r.a.value('@DisplayName','varchar(250)'),
    r.a.value('@EmailHash','varchar(125)'),
    r.a.value('@LastAccessDate','datetime'),
    r.a.value('@WebsiteUrl','varchar(250)'),
    r.a.value('@Location','varchar(250)'),
    r.a.value('@Age','int'),
    r.a.value('@AboutMe','varchar(max)'),
    r.a.value('@Views','int'),
    r.a.value('@UpVotes','int'),
    r.a.value('@DownVotes','int')
FROM @messagebody.nodes('/users/row') AS r(a)
GO
PRINT '[x] Users data loaded'

/* Votes */
DECLARE @messagebody XML
SELECT @messagebody = BulkColumn
FROM OPENROWSET(BULK 'C:\temp\StackExchange\raspberrypi.stackexchange.com\Votes.xml',SINGLE_CLOB) AS x

INSERT INTO [dbo].[Votes] ([Id],[PostId],[VoteTypeId],[CreationDate],[UserId],[BountyAmount])
SELECT
    r.a.value('@Id','int'),
    r.a.value('@PostId','int'),
    r.a.value('@VoteTypeId','int'),
    r.a.value('@CreationDate','datetime'),
    r.a.value('@UserId','int'),
    r.a.value('@BountyAmount','int')
FROM @messagebody.nodes('/votes/row') AS r(a)
GO
PRINT '[x] Votes data loaded'

PRINT '********DONE********'