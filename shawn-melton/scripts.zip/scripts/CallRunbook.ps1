$PSDefaultParameterValues;

$params = @{
    server = @('sql2016-01','sql2016-02')
}
Start-AzAutomationRunbook -Name Get-DiskSpace -Parameters $params -RunOn azure -Wait

$params = @{
    instance = @('sql2016-01','sql2016-02')
    stackdb  = 'beer'
    number   = 2
}
Start-AzAutomationRunbook -Name Restore-Database -Parameters $params -RunOn azure -Wait

<# Webhook #>
$params = @{
    Uri    = 'https://s1events.azure-automation.net/webhooks?token=iQM%2f7u4yyWE2rcbdMUxeX4QiPUbc0X1faPfr%2bz1R8QE%3d'
    Method = 'POST'
}
Invoke-WebRequest @params