param(
    [string[]]$instance,
    [string]$stackdb,
    [int]$number
)

#region Azure
$storageAccount = Get-AutomationVariable -Name 'sqlsatatlstorage_account'
$storageContainer = Get-AutomationVariable -Name 'sqlsatatlstorage_container'
$sqlCred = Get-AutomationPSCredential -Name 'sqlcred'
#endregion Azure

foreach ($i in $instance) {
    $path = "https://$storageAccount.blob.core.windows.net/$storageContainer/$stackdb.bak"
    try {
        if ($number -gt 0) {
            for ($x = 1; $x -le $number; $x++) {
                $params = @{
                    SqlInstance                      = $i
                    SqlCredential                    = $sqlCred
                    Path                             = $path
                    UseDestinationDefaultDirectories = $true
                    ReplaceDbNameInFile              = $true
                    DatabaseName                     = "$($stackdb)_$($x)"
                    WithReplace                      = $true
                }
                Restore-DbaDatabase @params
            }
        } else {
            $params = @{
                SqlInstance                      = $i
                SqlCredential                    = $sqlCred
                Path                             = $path
                UseDestinationDefaultDirectories = $true
                ReplaceDbNameInFile              = $true
                DatabaseName                     = "$stackdb"
            }
            Restore-DbaDatabase @params
        }
    } catch {
        throw "$_"
    }
}