param(
    [string[]]$instance
)
$sqlCred = Get-AutomationPSCredential -Name 'sqlcred'

foreach ($i in $instance) {
    try {
        $params = @{
            SqlInstance   = $i
            SqlCredential = $sqlCred
            EnableException = $true
        }
        Get-DbaInstanceProperty @params
    } catch {
        throw "$_"
    }
}