#region AzureSqlDb
$azSqlServer = Get-AutomationVariable -Name 'AzureSqlServer'
$azSqlDb = Get-AutomationVariable -Name 'AzureSqlDatabase'
$azSqlCred = Get-AutomationPSCredential -Name 'dbatoolspbi.sql'
#endregion AzureSqlDb

$domainCred = Get-AutomationPSCredential -Name 'dbatoolspbi.sql'

$writeParams = @{
    SqlInstance     = $azSqlServer
    Database        = $azSqlDb
    SqlCredential   = $azSqlCred
    Table           = 'servers'
    AutoCreateTable = $true
}

try {
    $servers = Get-AdComputer -Filter * -SearchBase 'OU=SQLServers,DC=dbatools,DC=local' -Credential $domainCred
} catch {
    Write-Error "Issue gathering AD server list: `n$_"
}

if ($servers.Count -gt 0 -or $servers.Length -gt 0) {
    foreach ($server in $servers) {
        try {
            Write-Output "Working on: $($server.DNSHostName)"
            $params = @{
                ComputerName    = $server
                Credential      = $domainCred
                ScanType = 'SqlService'
                EnableException = $true
            }
            $results = Find-DbaInstance @params | Select-Object -ExpandProperty Services
            foreach ($prop in $results) {
                Add-Member -InputObject $prop -MemberType NoteProperty -Name CaptureDate -Value (Get-Date) -Force
            }
            $results | Select-Object CaptureDate, ComputerName, InstanceName, State, ServiceName, ServiceType, DisplayName, StartName, StartMode | Write-DbaDataTable @writeParams
        } catch {
            throw "$_"
        }
    }
}