param(
    [string[]]$instance
)
$domainCred = Get-AutomationPSCredential -Name 'dbatools.local'
$sqlCred = Get-AutomationPSCredential -Name 'sqlcred'

foreach ($i in $instance) {
    try {
        $params = @{
            SqlInstance   = $i
            Credential    = $domainCred
            SqlCredential = $sqlCred
        }
        Test-DbaConnection @params | Select-Object ComputerName, SqlInstance, ConnectSuccess, ConnectingAsUser, AuthType
    } catch {
        throw "$_"
    }
}