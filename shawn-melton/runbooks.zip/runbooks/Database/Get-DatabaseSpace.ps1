param (
    [string[]]$instance
)

#region AzureSqlDb
$azSqlServer = Get-AutomationVariable -Name 'AzureSqlServer'
$azSqlDb = Get-AutomationVariable -Name 'AzureSqlDatabase'
$azSqlCred = Get-AutomationPSCredential -Name 'dbatoolspbi.sql'
#endregion AzureSqlDb

$sqlCred = Get-AutomationPSCredential -Name 'sqlcred'

$writeParams = @{
    SqlInstance     = $azSqlServer
    Database        = $azSqlDb
    SqlCredential   = $azSqlCred
    Table           = 'databasespace'
    AutoCreateTable = $true
}
foreach ($instance in $instance) {
    try {
        Write-Output "Working on: $instance"
        $params = @{
            SqlInstance     = $instance
            SqlCredential   = $sqlCred
            EnableException = $true
        }
        $results = Get-DbaDbSpace @params
        foreach ($prop in $results) {
            Add-Member -InputObject $prop -MemberType NoteProperty -Name CaptureDate -Value (Get-Date) -Force
            Add-Member -InputObject $prop -MemberType NoteProperty -Name DriveLetter -Value (($prop.PhysicalName -split ":")[0])
        }
        $results | Write-DbaDataTable @writeParams
    } catch {
        throw "$_"
    }
}