param (
    [string[]]$instance
)

#region AzureSqlDb
$azSqlServer = Get-AutomationVariable -Name 'AzureSqlServer'
$azSqlDb = Get-AutomationVariable -Name 'AzureSqlDatabase'
$azSqlCred = Get-AutomationPSCredential -Name 'dbatoolspbi.sql'
#endregion AzureSqlDb

$sqlCred = Get-AutomationPSCredential -Name 'sqlcred'

$writeParams = @{
    SqlInstance     = $azSqlServer
    Database        = $azSqlDb
    SqlCredential   = $azSqlCred
    Table           = 'databaseinfo'
    AutoCreateTable = $true
}
foreach ($i in $instance) {
    try {
        Write-Output "Working on: $i"
        $params = @{
            SqlInstance     = $i
            SqlCredential   = $sqlCred
            EnableException = $true
        }
        $results = Get-DbaDatabase @params
        foreach ($prop in $results) {
            Add-Member -InputObject $prop -MemberType NoteProperty -Name CaptureDate -Value (Get-Date) -Force
        }
        $results | Write-DbaDataTable @writeParams
    } catch {
        throw "$_"
    }
}