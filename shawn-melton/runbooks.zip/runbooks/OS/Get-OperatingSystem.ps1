param (
    [string[]]$server
)

#region AzureSqlDb
$azSqlServer = Get-AutomationVariable -Name 'AzureSqlServer'
$azSqlDb = Get-AutomationVariable -Name 'AzureSqlDatabase'
$azSqlCred = Get-AutomationPSCredential -Name 'dbatoolspbi.sql'
#endregion AzureSqlDb

$localCred = Get-AutomationPSCredential -Name 'localserver'

$writeParams = @{
    SqlInstance     = $azSqlServer
    Database        = $azSqlDb
    SqlCredential   = $azSqlCred
    Table           = 'osinfo'
    AutoCreateTable = $true
}
foreach ($s in $server) {
    try {
        $params = @{
            ComputerName    = $s
            Credential      = $localCred
            EnableException = $true
        }
        $results = Get-DbaOperatingSystem @params
        foreach ($prop in $results) {
            Add-Member -InputObject $prop -MemberType NoteProperty -Name CaptureDate -Value (Get-Date) -Force
        }
        $results | Write-DbaDataTable @writeParams
    } catch {
        Write-Error "Error in execution: $_"
        $log = Get-DbatoolsLog -Errors | Select-Object -Last 1
        .\Write-LogEntry.ps1 -InputObject $log
    }
}