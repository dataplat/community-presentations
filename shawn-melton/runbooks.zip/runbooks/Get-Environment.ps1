$servers = .\Get-ServerList.ps1

foreach ($server in $servers) {
    $currentInstance = $server.SqlInstance
    $currentComputer = $server.ComputerName
    Write-Output "Working on: $currentInstance"

    $testCn = .\Test-SqlConnection.ps1 -instance $currentInstance
    if ($testCn.ConnectSuccess) {
        #region OSInfo
        .\Get-ComputerSystem.ps1 -server $currentComputer

        .\Get-OperatingSystem.ps1 -server $currentComputer

        .\Get-DiskSpace.ps1 -server $currentComputer
        #endregion OSInfo

        #region SqlInfo
        .\Get-DatabaseInfo.ps1 -instance $currentInstance

        .\Get-DatabaseSpace.ps1 -instance $currentInstance
        #endregion SqlInfo
    }
}