Write-Output "This is a test"
$servers = 'sql2008r20', 'doesnotexist', 'sql2008r21'

#region AzureSqlDb
$azSqlServer = Get-AutomationVariable -Name 'AzureSqlServer'
$azSqlDb = Get-AutomationVariable -Name 'AzureSqlDatabase'
$azSqlCred = Get-AutomationPSCredential -Name 'dbatoolspbi.sql'
#endregion AzureSqlDb

$localCred = Get-AutomationPSCredential -Name 'localadmin'

$writeParams = @{
    SqlInstance     = $azSqlServer
    Database        = $azSqlDb
    SqlCredential   = $azSqlCred
    Table           = 'diskspace'
    AutoCreateTable = $true
}
foreach ($server in $servers) {
    try {
        Write-Output "Working on: $server"
        $params = @{
            ComputerName    = $server
            Credential      = $localCred
            EnableException = $true
        }
        $results = Get-DbaDiskSpace @params
        foreach ($prop in $results) {
            Add-Member -InputObject $prop -MemberType NoteProperty -Name CaptureDate -Value (Get-Date) -Force
        }
        $results | Write-DbaDataTable @writeParams
    } catch {
        Write-Error "Error in execution: $_"
        $log = Get-DbatoolsLog -Errors | Select-Object -Last 1
        .\Write-LogEntry.ps1 -InputObject $log
    }
}