<#
    .SYNOPSIS
    Test output streams for PowerShell in context of a Runbook
    .DESCRIPTION
    Main streams in PowerShell:
        - Output
        - Warning
        - Error
        - Verbose
        - Progress
        - Debug
#>

<# Output #>
Write-Output "Todays date: $(Get-Date)"

<# Warning #>
Write-Warning "Warning message"

<# Error #>
Write-Error "Error message"

<# Verbose #>
Write-Verbose "Verbose message"

<# Debug #>
<# *****DO NOT USE IT ******** #>

<# Progress #>
for ($i=1; $i -le 10; $i++) {
    Write-Progress -Activity 'Progress example Update ->' -Status 'Progress ->' -PercentComplete $i -CurrentOperation OuterLoop
    for ($j=1; $j -lt 10; $j++) {
        Write-Progress -Id 1 -Activity Updating -Status 'Progress -->' -PercentComplete $j -CurrentOperation InnerLoop
    }
}
