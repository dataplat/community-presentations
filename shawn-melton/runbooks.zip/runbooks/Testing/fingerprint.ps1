function Invoke-Fingerprint {
    param(
        $cmd
    )
    Write-Output '--------------------------------'
    Write-Output $cmd
    Invoke-Expression $cmd
}

<# gathering some details #>
Invoke-Fingerprint 'pwd'
Invoke-Fingerprint 'whoami'
Invoke-Fingerprint '$PSVersionTable'
# Invoke-Fingerprint 'Get-Module -ListAvailable'

Invoke-Fingerprint 'Write-Output "Verbose preference: $VerbosePreference"'
