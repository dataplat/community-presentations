param(
    [string[]]$servers
)
#region AzureSqlDb
$azSqlServer = Get-AutomationVariable -Name 'AzureSqlServer'
$azSqlDb = Get-AutomationVariable -Name 'AzureSqlDatabase'
$azSqlCred = Get-AutomationPSCredential -Name 'dbatoolspbi.sql'
#endregion AzureSqlDb
if ($servers.Length -gt 0 -or $servers.Count -gt 0) {
    $query = "SELECT ComputerName,
    CASE InstanceName
        WHEN 'MSSQLSERVER' THEN NULL
        ELSE InstanceName
    END AS InstanceName,
    MAX(CaptureDate) AS LastCapture
    FROM servers
    WHERE ComputerName IN (@servers)
        AND CaptureDate > '05/03/2019'
    GROUP BY CaptureDate, ComputerName, InstanceName"
} else {
    $query = "SELECT ComputerName,
    CASE InstanceName
        WHEN 'MSSQLSERVER' THEN NULL
        ELSE InstanceName
    END AS InstanceName,
    MAX(CaptureDate) AS LastCapture
    FROM servers
    WHERE CaptureDate > '05/03/2019'
    GROUP BY CaptureDate, ComputerName, InstanceName"
}

try {
    $serverList = $servers -join ''','''
    $params = @{
        SqlInstance     = $azSqlServer
        Database        = $azSqlDb
        SqlCredential   = $azSqlCred
        Query           = $query
        SqlParameters   = @{ servers = "'$serverList'"}
        EnableException = $true
        As              = "PSObject"
    }
    $results = Invoke-DbaQuery @params
    foreach ($i in $results) {
        $sqlInstance = ([string]::Join('\',$i.ComputerName,$server.InstanceName)).Trim("\")
        [PSCustomObject]@{
            ComputerName = $i.ComputerName
            SqlInstance  = $sqlInstance
        }
    }
} catch {
    throw "$_"
}