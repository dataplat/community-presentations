param(
    $InputObject
)
#region AzureSqlDb
$azSqlServer = Get-AutomationVariable -Name 'AzureSqlServer'
$azSqlDb = Get-AutomationVariable -Name 'AzureSqlDatabase'
$azSqlCred = Get-AutomationPSCredential -Name 'dbatoolspbi.sql'
#endregion AzureSqlDb
$errorLog = Get-AutomationVariable -Name 'tableSessionLog'
try {
    $params = @{
        SqlInstance     = $azSqlServer
        Database        = $azSqlDb
        SqlCredential   = $azSqlCred
        Table           = $errorLog
        AutoCreateTable = $true
        EnableException = $true
    }
    $InputObject | Write-DbaDataTable @params
} catch {
    Write-Error "Issue trying to write error to log table"
    $_
}