$server = .\Get-ServerList.ps1

#region Azure Resources
$storageAccount = Get-AutomationVariable -Name 'sqlsatatlstorage_account'
$storageContainer = Get-AutomationVariable -Name 'sqlsatatlstorage_container'
$storageSasKey = Get-AutomationVariable -Name 'sqlsatatlstorage_sas_key'
$sqlcred = Get-AutomationPSCredential -Name 'sqlcred'

$secureAccessKey = $storageSasKey | ConvertTo-SecureString -AsPlainText -Force
#endregion Azure Resources

foreach ($s in $server) {
    Write-Output "Working on: $($s.SqlInstance)"
    $name = "https://$storageAccount.blob.core.windows.net/$storageContainer"

    $params = @{
        SqlInstance   = $s.SqlInstance
        SqlCredential = $sqlcred
        Name          = $name
    }
    Write-Output "Creating credential: $name"
    $params = @{
        SqlInstance    = $s.SqlInstance
        SqlCredential  = $sqlcred
        Name           = $name
        Identity       = "Shared Access Signature"
        SecurePassword = $secureAccessKey
        Force          = $true
    }
    New-DbaCredential @params

    Write-Output "Credential created"
}