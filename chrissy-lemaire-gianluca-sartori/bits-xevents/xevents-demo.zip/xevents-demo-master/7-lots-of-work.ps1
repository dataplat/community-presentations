﻿# Complaint: I'm lazy and XEs are a lot of work
# Answer: Can't get any lazier than using PowerShell
Get-ChildItem C:\corpxetemplates | Import-DbaXESessionTemplate -SqlInstance $servers