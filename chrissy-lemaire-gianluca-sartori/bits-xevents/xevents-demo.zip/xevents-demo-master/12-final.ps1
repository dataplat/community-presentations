﻿# Complaint: It's harder than Profiler to train others
# Answer: Now it's as easy as teaching a couple PowerShell commnds

# Complaint: "XEs are more efficient for the SQL Server engine, but not more efficient for the DBA"


# Answer: PowerShell, CLOSED AS FIXED













. C:\temp\finale.ps1