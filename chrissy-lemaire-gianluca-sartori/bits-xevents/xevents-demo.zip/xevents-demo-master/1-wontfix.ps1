﻿# Complaint: Consistent interface for mixed environments
# Answer: CLOSED, WON'T FIX
# Complaint: MS Premier Support still asks for traces
# Answer: CLOSED, WON'T FIX
# Complaint: Consistent user experience across SSAS and Database Engine
# Answer: Need more information