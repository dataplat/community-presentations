use master
go

if exists (select * from sys.databases where name='RestoreTimeCopyOnly')
begin
	ALTER DATABASE RestoreTimeCopyOnly SET single_USER with rollback immediate
	drop database RestoreTimeCopyOnly
end
go


create database RestoreTimeCopyOnly
go

alter database RestoreTimeCopyOnly set recovery full
go

use RestoreTimeCopyOnly
go

IF EXISTS (SELECT * FROM SYS.tables WHERE name='steps')
begin
	drop table steps
end
go

create table steps(
step integer,
dt datetime2
);
go

declare @i integer

set @i=0


backup database [RestoreTimeCopyOnly] to disk='c:\dbatools\RestoreTimeCopyOnly\RestoreTimeCopyOnly.bak'

while (@i<10)
begin
insert into steps values (@i, getdate())
select @i=@i+1
waitfor delay '00:00:30'
end
backup log [RestoreTimeCopyOnly] to disk='c:\dbatools\RestoreTimeCopyOnly\RestoreTimeCopyOnly_1.trn'


while (@i<20)
begin
insert into steps values (@i,getdate())
select @i=@i+1
waitfor delay '00:00:30'
end

backup log [RestoreTimeCopyOnly] to disk='c:\dbatools\RestoreTimeCopyOnly\RestoreTimeCopyOnly_2.trn'

while (@i<30)
begin
insert into steps values (@i,getdate())
select @i=@i+1
waitfor delay '00:00:30'
end


backup log [RestoreTimeCopyOnly] to disk='c:\dbatools\RestoreTimeCopyOnly\RestoreTimeCopyOnly_3.trn'

backup database [RestoreTimeCopyOnly] to disk='c:\dbatools\RestoreTimeCopyOnly\RestoreTimeCopyOnly2.bak' with Copy_only

set @i=0
while (@i<10)
begin
insert into steps values (@i, getdate())
select @i=@i+1
waitfor delay '00:00:30'
end
backup log [RestoreTimeCopyOnly] to disk='c:\dbatools\RestoreTimeCopyOnly\RestoreTimeCopyOnly_21.trn'

while (@i<20)
begin
insert into steps values (@i,getdate())
select @i=@i+1
waitfor delay '00:00:30'
end


backup log [RestoreTimeCopyOnly] to disk='c:\dbatools\RestoreTimeCopyOnly\RestoreTimeCopyOnly_22.trn'

while (@i<30)
begin
insert into steps values (@i,getdate())
select @i=@i+1
waitfor delay '00:00:30'
end


backup log [RestoreTimeCopyOnly] to disk='c:\dbatools\RestoreTimeCopyOnly\RestoreTimeCopyOnly_23.trn'

