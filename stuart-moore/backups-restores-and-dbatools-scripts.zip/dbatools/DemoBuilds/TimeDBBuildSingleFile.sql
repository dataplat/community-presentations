use master
go

if exists (select * from sys.databases where name='RestoreTimeSingleFile')
begin
	ALTER DATABASE RestoreTimeSingleFile SET single_USER with rollback immediate
	drop database RestoreTimeSingleFile
end
go


create database RestoreTimeSingleFile
go

alter database RestoreTimeSingleFile set recovery full
go

use RestoreTimeSingleFile
go

IF EXISTS (SELECT * FROM SYS.tables WHERE name='steps')
begin
	drop table steps
end
go

create table steps(
step integer,
dt datetime2
);
go

declare @i integer

set @i=0


backup database [RestoreTimeSingleFile] to disk='c:\dbatools\RestoreTimeSingleFile\RestoreTimeSingleFile.bak'

while (@i<10)
begin
insert into steps values (@i, getdate())
select @i=@i+1
waitfor delay '00:00:30'
end
backup log [RestoreTimeSingleFile] to disk='c:\dbatools\RestoreTimeSingleFile\RestoreTimeSingleFile.bak'

while (@i<20)
begin
insert into steps values (@i,getdate())
select @i=@i+1
waitfor delay '00:00:30'
end


backup log [RestoreTimeSingleFile] to disk='c:\dbatools\RestoreTimeSingleFile\RestoreTimeSingleFile.bak'

while (@i<30)
begin
insert into steps values (@i,getdate())
select @i=@i+1
waitfor delay '00:00:30'
end


backup log [RestoreTimeSingleFile] to disk='c:\dbatools\RestoreTimeSingleFile\RestoreTimeSingleFile.bak'

backup database [RestoreTimeSingleFile] to disk='c:\dbatools\RestoreTimeSingleFile\RestoreTimeSingleFile.bak'

set @i=0
while (@i<10)
begin
insert into steps values (@i, getdate())
select @i=@i+1
waitfor delay '00:00:30'
end
backup log [RestoreTimeSingleFile] to disk='c:\dbatools\RestoreTimeSingleFile\RestoreTimeSingleFile.bak'

while (@i<20)
begin
insert into steps values (@i,getdate())
select @i=@i+1
waitfor delay '00:00:30'
end


backup log [RestoreTimeSingleFile] to disk='c:\dbatools\RestoreTimeSingleFile\RestoreTimeSingleFile.bak'

while (@i<30)
begin
insert into steps values (@i,getdate())
select @i=@i+1
waitfor delay '00:00:30'
end


backup log [RestoreTimeSingleFile] to disk='c:\dbatools\RestoreTimeSingleFile\RestoreTimeSingleFile.bak'

