use master
go

if exists (select * from sys.databases where name='RestoreTime2012')
begin
	ALTER DATABASE RestoreTime2012 SET single_USER with rollback immediate
	drop database RestoreTime2012
end
go


create database RestoreTime2012
go

alter database RestoreTime2012 set recovery full
go

use RestoreTime2012
go

IF EXISTS (SELECT * FROM SYS.tables WHERE name='steps')
begin
	drop table steps
end
go

create table steps(
step integer,
dt datetime2
);
go

declare @i integer

set @i=0


backup database [RestoreTime2012] to disk='c:\dbatools\RestoreTime2012\RestoreTime2012.bak'

while (@i<10)
begin
insert into steps values (@i, getdate())
select @i=@i+1
waitfor delay '00:00:30'
end
backup log [RestoreTime2012] to disk='c:\dbatools\RestoreTime2012\RestoreTime2012_1.trn'


while (@i<20)
begin
insert into steps values (@i,getdate())
select @i=@i+1
waitfor delay '00:00:30'
end

backup log [RestoreTime2012] to disk='c:\dbatools\RestoreTime2012\RestoreTime2012_2.trn'

while (@i<30)
begin
insert into steps values (@i,getdate())
select @i=@i+1
waitfor delay '00:00:30'
end


backup log [RestoreTime2012] to disk='c:\dbatools\RestoreTime2012\RestoreTime2012_3.trn'

backup database [RestoreTime2012] to disk='c:\dbatools\RestoreTime2012\RestoreTime20122.bak'

set @i=0
while (@i<10)
begin
insert into steps values (@i, getdate())
select @i=@i+1
waitfor delay '00:00:30'
end
backup log [RestoreTime2012] to disk='c:\dbatools\RestoreTime2012\RestoreTime2012_21.trn'

while (@i<20)
begin
insert into steps values (@i,getdate())
select @i=@i+1
waitfor delay '00:00:30'
end


backup log [RestoreTime2012] to disk='c:\dbatools\RestoreTime2012\RestoreTime2012_22.trn'

while (@i<30)
begin
insert into steps values (@i,getdate())
select @i=@i+1
waitfor delay '00:00:30'
end


backup log [RestoreTime2012] to disk='c:\dbatools\RestoreTime2012\RestoreTime2012_23.trn'

