use master
go

if exists (select * from sys.databases where name='RestoreTimeRogueFile')
begin
	ALTER DATABASE RestoreTimeRogueFile SET single_USER with rollback immediate
	drop database RestoreTimeRogueFile
end
go
 

create database RestoreTimeRogueFile
go

alter database RestoreTimeRogueFile set recovery full
go

use RestoreTimeRogueFile
go

IF EXISTS (SELECT * FROM SYS.tables WHERE name='steps')
begin
	drop table steps
end
go

create table steps(
step integer,
dt datetime2
);
go




backup database [RestoreTimeRogueFile] to disk='c:\dbatools\RestoreTimeRogueFile\RestoreTimeRogueFile.bak'

declare @i integer

set @i=0

while (@i<10)
begin
insert into steps values (@i, getdate())
select @i=@i+1
waitfor delay '00:00:30'
end
backup log [RestoreTimeRogueFile] to disk='c:\dbatools\RestoreTimeRogueFile\RestoreTimeRogueFile_1.trn'

alter database [RestoreTimeRogueFile] 
add file
(	
	NAME = 'breakstuff',
	filename = 'c:\dbatools\RestoreTimeRogueFile\Roguefule.ndf',
	size = 100MB,
	MAXSize=100MB,
	Filegrowth= 5MB
);
go

declare @i integer

set @i=10

while (@i<20)
begin
insert into steps values (@i,getdate())
select @i=@i+1
waitfor delay '00:00:30'
end


backup log [RestoreTimeRogueFile] to disk='c:\dbatools\RestoreTimeRogueFile\RestoreTimeRogueFile_2.trn'

ALTER Database RestoreTimeRogueFile remove FILE  breakstuff;
go

declare @i integer

set @i=20
while (@i<30)
begin
insert into steps values (@i,getdate())
select @i=@i+1
waitfor delay '00:00:30'
end


backup log [RestoreTimeRogueFile] to disk='c:\dbatools\RestoreTimeRogueFile\RestoreTimeRogueFile_3.trn'

backup database [RestoreTimeRogueFile] to disk='c:\dbatools\RestoreTimeRogueFile\RestoreTimeRogueFile2.bak'

set @i=0
while (@i<10)
begin
insert into steps values (@i, getdate())
select @i=@i+1
waitfor delay '00:00:30'
end
backup log [RestoreTimeRogueFile] to disk='c:\dbatools\RestoreTimeRogueFile\RestoreTimeRogueFile_21.trn'

while (@i<20)
begin
insert into steps values (@i,getdate())
select @i=@i+1
waitfor delay '00:00:30'
end


backup log [RestoreTimeRogueFile] to disk='c:\dbatools\RestoreTimeRogueFile\RestoreTimeRogueFile_22.trn'

while (@i<30)
begin
insert into steps values (@i,getdate())
select @i=@i+1
waitfor delay '00:00:30'
end


backup log [RestoreTimeRogueFile] to disk='c:\dbatools\RestoreTimeRogueFile\RestoreTimeRogueFile_23.trn'

