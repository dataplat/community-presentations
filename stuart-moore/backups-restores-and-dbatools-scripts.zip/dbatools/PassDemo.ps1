﻿<#
Demo scripts from my PowerShell restores presentataion for PASS Virtual PowerShell chapter 21/03/2017
Video of presentaion - https://youtu.be/-q074XVYVPw

update 23/03/2017 - all features now in production release. Please update from the gallery

The adventureworks database I was using was downloaded from https://msftdbprodsamples.codeplex.com/ and then bumped up in size uing Jonathan Kehayias' script - https://www.sqlskills.com/blogs/jonathan/enlarging-the-adventureworks-sample-databases/

The other databases can be created using the .sql scripts in the DemoBuilds folder

Mail: stuart at stuart-moore dot com
Twitter: @napalmgram
Dbatools Slack : stuart-moore

#>

#Not the official way to do things, but I want to demo some bits that are coming soon
remove-module dbatools; import-module .\dbatools.psd1

######## backups
#Use Splatting to keep things clean:
$BackupParms = @{
                    SqlInstance = 'localhost\sqlexpress2016';
                    Databases = 'AdventureWorks';
                    BackupDirectory = 'c:\dbatools\backups\';
                }

Backup-DbaDatabase @BackupParms

Measure-Command {$BackupOutput = Backup-DbaDatabase @BackupParms}
 
#Striping across multiple files can speed things up
$BackupParms.add("FileCount",4)

Measure-Command {$BackupOutput = Backup-DbaDatabase @BackupParms}

$BackupParms.Remove("FileCount")

#No splatting now, as you can't splat an array :(
Measure-Command {$BackupOutput = Backup-DbaDatabase `
                                -SqlInstance localhost\sqlexpress2016 `
                                -Databases AdventureWorks `
                                -BackupDirectory c:\dbatools\backups\stripe1, c:\dbatools\backups\stripe2
                                }

#Be careful though, striping goes at the speed of the slowest disk
#For this example I had an old slow USB memory stick mounted as d:\

Measure-Command {$BackupOutput = Backup-DbaDatabase `
                                -SqlInstance localhost\sqlexpress2016 `
                                -Databases AdventureWorks `
                                -BackupDirectory  c:\dbatools\backups\stripe1, d:\StripeUsb
                                }

#So thats full backups, what about the others:
$BackupParms.add("Type", "Diff")
$BackupOutPut = Backup-DbaDatabase @BackupParms

#Oops! By design, Backup-DbaData takes CopyOnly backups. This stops you accidentaly breaking the restore chain.
$BackupParms.add("NoCopyOnly",$true)
$BackupParms.set_item("Type","Full")
$BackupOutPut = Backup-DbaDatabase @BackupParms

#Take 2
$BackupParms.set_item("Type","Diff")
$BackupOutPut = Backup-DbaDatabase @BackupParms

#That worked. Very fast as we've not modified any data
#How about logs
$BackupParms.set_item("Type","Log")
$BackupOutPut = Backup-DbaDatabase @BackupParms



#Check your backup. Verify reads the files and checks they are good
$BackupParms.Add("Verify",$True)
$BackupOutPut = Backup-DbaDatabase @BackupParms

# See What's been backed up:
Get-DbaBackupHistory -SqlServer localhost\sqlexpress2016 -Databases Adventureworks
Get-DbaBackupHistory -SqlServer localhost\sqlexpress2016 -Databases Adventureworks -lastfull -IgnoreCopyOnly

Get-DbaBackupHistory -SqlServer localhost\sqlexpress2016 -Databases Adventureworks -last

#That relies on the database having been backed up before, what happens if it's new?
Get-DbaDatabase -SqlInstance localhost\sqlexpress2016 -NoFullBackup

#And to fix that:

Get-DbaDatabase -SqlInstance localhost\sqlexpress2016 -NoFullBackup |
    Backup-DbaDatabase -BackupDirectory C:\dbatools\Backups -CreateFolder -NoCopyOnly

#What about stale full backups?
Get-DbaDatabase -SqlInstance localhost\sqlexpress2016 -NoFullBackupSince (get-date).Addminutes(-5)

####### restores

#A folder with full backups and transaction backups:
Get-ChildItem C:\dbatools\RestoreTimeClean

#A digression on what's in these test dbs

#Simplest, let's restore the intial full backup:
Restore-DbaDatabase -SqlServer localhost\sqlexpress2016 `
                    -DatabaseName TestRestore `
                    -Path C:\dbatools\RestoreTimeClean\restoretimeClean.bak `
                    -DestinationDataDirectory C:\dbatools\testrest 

#Now lets restore to the latest point in time
Restore-DbaDatabase -SqlServer localhost\sqlexpress2016 `
                    -DatabaseName TestRestore `
                    -Path C:\dbatools\RestoreTimeClean `
                    -DestinationDataDirectory C:\dbatools\testrest `
                     -withreplace

#So what about a point between those 2 extremes? 
#In my case between 2017-03-20 12:58:03.000 and 2017-03-20 13:13:03.000

Restore-DbaDatabase -SqlServer localhost\sqlexpress2016 `
                    -DatabaseName TestRestore `
                    -Path C:\dbatools\RestoreTimeClean `
                    -DestinationDataDirectory C:\dbatools\testrest `
                     -withreplace `
                     -RestoreTime (Get-date '20/03/2017 13:03')

Invoke-Sqlcmd2 -ServerInstance localhost\sqlexpress2016 -Query "select max(dt) from dbo.steps" -Database TestRestore


Restore-DbaDatabase -SqlServer localhost\sqlexpress2016 `
                    -DatabaseName TestRestore `
                    -Path C:\dbatools\RestoreTimeClean `
                    -DestinationDataDirectory C:\dbatools\testrest `
                     -withreplace `
                     -RestoreTime (Get-date '20/03/2017 13:12')

Invoke-Sqlcmd2 -ServerInstance localhost\sqlexpress2016 -Query "select max(dt) from dbo.steps" -Database TestRestore

#And now for a diff backup
Restore-DbaDatabase -SqlServer localhost\sqlexpress2016 `
                    -DatabaseName TestRestore `
                    -Path C:\dbatools\RestoreTimeDiff `
                    -DestinationDataDirectory C:\dbatools\testrest `
                     -withreplace `
                     -RestoreTime (get-Date '21/03/2017 11:37') `
                     -OutputScriptOnly

Restore-DbaDatabase -SqlServer localhost\sqlexpress2016 `
                    -DatabaseName TestRestore `
                    -Path C:\dbatools\RestoreTimeDiff `
                    -DestinationDataDirectory C:\dbatools\testrest `
                     -withreplace `
                     -RestoreTime (get-Date '21/03/2017 11:40') 

Invoke-Sqlcmd2 -ServerInstance localhost\sqlexpress2016 -Query "select max(dt) from dbo.steps" -Database TestRestore

<#
Let's slow it down and see what's happening under the hood using verbose. Oh, and we can just drop out the scripts if you 
want to squirrel them away for a bad day
#>

Restore-DbaDatabase -SqlServer localhost\sqlexpress2016 `
                    -DatabaseName TestRestore `
                    -Path C:\dbatools\RestoreTimeClean `
                    -DestinationDataDirectory C:\dbatools\testrest `
                     -withreplace `
                     -RestoreTime (Get-date '20/03/2017 13:12') `
                     -OutputScriptOnly `
                     -verbose

#So how do we cope if someone's done something silly:
(get-Item C:\dbatools\RestoreTimeClean\restoretimeClean.bak).LastWriteTime = Get-date

Get-ChildItem C:\dbatools\RestoreTimeClean\

Restore-DbaDatabase -SqlServer localhost\sqlexpress2016 `
                    -DatabaseName TestRestore `
                    -Path C:\dbatools\RestoreTimeClean `
                    -DestinationDataDirectory C:\dbatools\testrest `
                     -withreplace `
                     -RestoreTime (Get-date '20/03/2017 13:12')

Invoke-Sqlcmd2 -ServerInstance localhost\sqlexpress2016 -Query "select max(dt) from dbo.steps" -Database TestRestore

#Not an issue. We're relying on the LSN in the headers, not the file timestamps.

#A file is not always what it appears:
Restore-DbaDatabase -SqlServer localhost\sqlexpress2016 `
                    -DatabaseName TestRestore `
                    -Path C:\dbatools\restoretimesinglefile  `
                    -DestinationDataDirectory C:\dbatools\testrest `
                     -withreplace `
                     -OutputScriptOnly 

<#
That happens when people fix their backup file name and forget to FORMAT/INIT between backups.
You end up with all the backups in a single file (which get's BIG, seen them where it's bigger than the db)

Now, what happens if you've got other file patterns

let's start with Ola Hallengren's maintenance format:
#>

Get-ChildItem C:\dbatools\RestoreTimeOla -Recurse

Restore-DbaDatabase -SqlServer localhost\sqlexpress2016 `
                    -DatabaseName TestRestore `
                    -Path C:\dbatools\RestoreTimeOla `
                    -DestinationDataDirectory C:\dbatools\testrest `
                    -MaintenanceSolutionBackup `
                    -WithReplace 

#What happens if you can't access your backup files, but your SQL Server instance can. Then you can use our XP_dirtree option
Restore-DbaDatabase -SqlServer localhost\sqlexpress2016 `
                    -DatabaseName TestRestore `
                    -Path C:\dbatools\RestoreTimeOla `
                    -DestinationDataDirectory C:\dbatools\testrest `
                    -XpDirTree `
                    -WithReplace 

<#
All of our switches do a little bit of sanity checking and just take .bak and .trn files

We also take pipeline input for files, so you can build stuff up to your hearts content and ignore our restrictions

For this bit, I just copied one of the backup folders into C:\dbatools\RestoreTimeWtf and randomly changed names and file extensions

we Don't care what you pipe in:
#>

Get-ChildItem C:\dbatools\RestoreTimeWtf 

Get-ChildItem C:\dbatools\RestoreTimeWtf| Restore-DbaDatabase -SqlServer localhost\sqlexpress2016 `
                    -DatabaseName TestRestore `
                    -DestinationDataDirectory C:\dbatools\testrest `
                     -withreplace 

#If you're striping your backups, you can pass in multiple locations and we'll work with them:                     

Get-ChildItem C:\dbatools\RestoreTimeStripe\Stripe1, C:\dbatools\RestoreTimeStripe\Stripe2 | 
Restore-DbaDatabase -SqlServer localhost\sqlexpress2016 `
                    -DatabaseName TestRestore `
                    -DestinationDataDirectory C:\dbatools\TestRest `
                     -withreplace 

#Coping with File creation
Restore-DbaDatabase -SqlServer localhost\sqlexpress2016 `
                    -DatabaseName testrestore `
                    -DestinationDataDirectory C:\dbatools\TestRest `
                     -Path C:\dbatools\RestoreTimeRogueFile `
                     -WithReplace 

Restore-DbaDatabase -SqlServer localhost\sqlexpress2016 `
                    -DatabaseName testrestore `
                    -DestinationDataDirectory C:\dbatools\TestRest `
                     -Path C:\dbatools\RestoreTimeRogueFile `
                     -WithReplace `
                     -RestoreTime (get-date '21/03/2017 13:15')

#And now for some relocation tricks:

#Prefix all the restored database files. Handy if you need to restore them into a folder with the existing database
Restore-DbaDatabase -SqlServer localhost\sqlexpress2016 `
                    -DatabaseName TestRestore `
                    -Path C:\dbatools\RestoreTimeRogueFile `
                    -DestinationDataDirectory C:\dbatools\testrest `
                     -withreplace `
                     -DestinationFilePrefix Restored

#Restore the logs to a seperate path to the data files
Restore-DbaDatabase -SqlServer localhost\sqlexpress2016 `
                    -DatabaseName TestRestore `
                    -Path C:\dbatools\RestoreTimeRogueFile `
                    -DestinationDataDirectory C:\dbatools\testrest `
                     -withreplace `
                     -DestinationLogDirectory C:\dbatools\testrest\logrest

<#
If you're moving between servers, you can use the UseDestinationDefaultDirectories to ensure your new dbs are in the 
target instances usuall location. Using a file prefix helps avoid any issues
#>

Restore-DbaDatabase -SqlServer localhost\sqlexpress2016 `
                    -DatabaseName TestRestore `
                    -Path C:\dbatools\RestoreTimeClean `
                    -DestinationDataDirectory C:\dbatools\testrest `
                    -withreplace `
                    -UseDestinationDefaultDirectories `
                    -DestinationFilePrefix rest

<#
So far, we've only been looking at single databases, but hey we can do better than that!

Let's start off by passing 2 backup folders of backups
#>

Get-ChildItem C:\dbatools\RestoreTimeClean\, C:\dbatools\RestoreTimeDiff -Recurse | 
                    Restore-DbaDatabase -SqlServer localhost\sqlexpress2016 `
                    -RestoredDatababaseNamePrefix restored `
                    -DestinationDataDirectory C:\dbatools\testrest `
                    -withreplace `
                    -UseDestinationDefaultDirectories `
                    -DestinationFilePrefix rest 
<#
You can pass in as many backupsets as you want as long as you don't have conflicting names! 
I have a cunning plan to allow that, but it's at the bottom of a very long list

But that's enough about files, lets use some other cmdlets to push data for restore

Let's start with Get-DbaBackupHistory

This will work across instances, as long as both instances can see that backup media

So here's a
#>

Get-DbaBackupHistory -SqlServer localhost\sqlexpress2012 -Databases RestoreTime2012 |
                    Restore-DbaDatabase -SqlServer localhost\sqlexpress2016 `
                    -RestoredDatababaseNamePrefix restored `
                    -DestinationDataDirectory C:\dbatools\testrest `
                    -withreplace `
                    -DestinationFilePrefix rest 

Get-DbaBackupHistory -SqlServer localhost\sqlexpress2016 -Databases  RestoreTimeDiff, RestoreTimeClean, RestoreTimeSingleFile|
                    Restore-DbaDatabase -SqlInstance localhost\sqlexpress2016 `
                    -RestoredDatababaseNamePrefix restored `
                    -DestinationDataDirectory C:\dbatools\testrest `
                    -withreplace `
                    -DestinationFilePrefix rest 

stuart@stuart-moore.com

<#
Now, this is one of the few places we allow overiding the checking of the files.
 If the information is coming from backuphistory 
then we will trust it, to an extent!

#>

Get-DbaBackupHistory -SqlServer localhost\sqlexpress2016 -Databases restoretimeClean, RestoreTimeDiff, RestoreTimeSingleFile |
                    Restore-DbaDatabase -SqlServer localhost\sqlexpress2016 `
                    -RestoredDatababaseNamePrefix restored `
                    -DestinationDataDirectory C:\dbatools\testrest `
                    -withreplace `
                    -DestinationFilePrefix rest `
                    -TrustDbBackupHistory

<#
we still check the files actually exist, than you have a full LSN chain based on the history passed in, and that you're not 
breaking any version rules. But it does avoid the overhead of reading file headers

This does make difference as shown here, which will be larger for more complex restores using more files
#>
Measure-Command {Get-DbaBackupHistory -SqlServer localhost\sqlexpress2016 -Databases restoretimeClean, RestoreTimeDiff, RestoreTimeSingleFile |
                    Restore-DbaDatabase -SqlServer localhost\sqlexpress2016 `
                    -RestoredDatababaseNamePrefix restored `
                    -DestinationDataDirectory C:\dbatools\testrest `
                    -withreplace `
                    -DestinationFilePrefix rest}

Measure-Command {Get-DbaBackupHistory -SqlServer localhost\sqlexpress2016 -Databases restoretimeClean, RestoreTimeDiff, RestoreTimeSingleFile |
                    Restore-DbaDatabase -SqlServer localhost\sqlexpress2016 `
                    -RestoredDatababaseNamePrefix restored `
                    -DestinationDataDirectory C:\dbatools\testrest `
                    -withreplace `
                    -DestinationFilePrefix rest `
                    -TrustDbBackupHistory}


#Perhaps you just want to duplicate a database with minimal overhead?

Backup-DbaDatabase -SqlInstance localhost\sqlexpress2016 -Databases restoretimeClean |
    Restore-DbaDatabase -SqlServer localhost\sqlexpress2016 `
                        -DatabaseName restoretimeclone `
                        -DestinationDataDirectory C:\dbatools\TestRest `
                        -DestinationLogDirectory C:\dbatools\TestRest `
                        -DestinationFilePrefix clone `
                        -WithReplace 

#And we can go better, want to practice a migration:

Backup-DbaDatabase -SqlInstance localhost\sqlexpress2012 -Databases RestoreTime2012 | 
    Restore-DbaDatabase -SqlServer localhost\sqlexpress2016 `
                        -DatabaseName RestoreTimeUpgrade `
                        -DestinationDataDirectory C:\dbatools\TestRest `
                        -DestinationLogDirectory C:\dbatools\TestRest `
                        -DestinationFilePrefix clone `
                        -WithReplace 

<#
As Backup-DbaDatabase uses CopyOnly backups, there's no impact on the original database

And, as usual with dbatools, why stop at one:
#>

Backup-DbaDatabase -SqlInstance localhost\sqlexpress2012 -Databases restoretime, RestoreTime2012 | 
    Restore-DbaDatabase -SqlServer localhost\sqlexpress2016 `
                        -RestoredDatababaseNamePrefix Upgraded `
                        -DestinationDataDirectory C:\dbatools\TestRest `
                        -DestinationLogDirectory C:\dbatools\TestRest `
                        -DestinationFilePrefix Upgraded `
                        -WithReplace 

